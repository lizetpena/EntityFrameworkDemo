﻿param($installPath, $toolsPath, $package, $project)

Import-Module (Join-Path $toolsPath EntityFramework.Migrations.Commands.dll)
