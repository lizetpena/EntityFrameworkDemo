﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ADOv3.EDMX;
using System.Data.Entity;

namespace GettingStarted.UI.EFAdvancedMapping
{
    public partial class TablePerTypeIneritance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (NorthwindEFEntities ctx = new NorthwindEFEntities())
            {
                //-- Now, StateTaxAudit entity "inherits" the TaxAudit entity.
                //-- No longer need to navigate from StateTaxAudit to TaxAudit 
                //-- to get TaxAudit Information.
                var query = from stateAudit in ctx.TaxAudit.OfType<StateTaxAudit>().OrderBy(t=>t.AuditDate) select stateAudit;

                gvBefore.DataSource = query;
                gvBefore.DataBind();

                //-- Create new StateTaxAudit record
                StateTaxAudit stateTaxAudit = new StateTaxAudit();

                //-- Fields from StateTaxAudit
                stateTaxAudit.Agency = "Texas Franchise Tax Board";
                stateTaxAudit.State = "TX";
                stateTaxAudit.SalesUseTax = false;
                stateTaxAudit.ID = new Random().Next(100000);

                //-- Fields inherited from TaxAudit
                stateTaxAudit.Audtor = "Rob Vettor";
                stateTaxAudit.AuditReason = "Routine";
                stateTaxAudit.Adjustment = Convert.ToDecimal(new Random().Next(10000000));
                stateTaxAudit.AuditDate = DateTime.Now;

                //-- Attach to parent, TaxAudit
                ctx.AddToTaxAudit(stateTaxAudit);

                //-- Next, EF first creates new TaxAudit AND StateTaxAudit Record
                ctx.SaveChanges();

                var queryAfter = from stateAudit in ctx.TaxAudit.OfType<StateTaxAudit>().OrderBy(t => t.AuditDate) select stateAudit;

                gvAfter.DataSource = queryAfter;
                gvAfter.DataBind();                
            }
        }
    }
}
