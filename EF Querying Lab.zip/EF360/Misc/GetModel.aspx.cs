﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace EF360CodeOnly.Misc
{
    public partial class GetModel : System.Web.UI.Page
    {
        //EF360CodeOnly ctx = new EF360CodeOnly();();
        
        //protected void Page_Load(object sender, EventArgs e)
        //{
        //    XmlWriterSettings settings = new XmlWriterSettings() { Indent = true };

        //    var virtualPath = @"~/DAL/Model";


        //    using (XmlWriter writer = XmlWriter.Create(@"S:\My LocalDocuments\Visual Studio 2010\EF360CodeOnly\Domain\Model\Model.edmx", settings))

        //    //using (XmlWriter writer = XmlWriter.Create(Server.MapPath(virtualPath) + @"\Model.edmx", settings))
        //    {
        //        EdmxWriter.WriteEdmx(ctx, writer);
        //    }          
        //}
    }
}