﻿using System;
using System.Linq;
using System.Web.UI;
using DAL.Model;

namespace EF360CodeOnly.Querying
{
    public partial class Projection : Page
    {
        #region Concrete Class Definition

        //-- Concrete type to represent each object in sequence
        public class ConcreteClass
        {
            public decimal? TotalPrice { get; set; }
            public decimal? LowPrice { get; set; }
            public decimal? HighPrice { get; set; }
            public decimal? AveragePrice { get; set; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            //-- Project Entire Sequence
            //-- Filter on price < $20, taking first 5 records,
            //-- Return entire entity. 
            using (var ctx = new EF360Context())
            {
                var queryEntireObject = (from p in ctx.Products
                                         where p.UnitPrice < 20
                                         select p).Take(5);
                gvEntireObject.DataSource = queryEntireObject;
                gvEntireObject.DataBind();
            }


            //-- Project Single Element
            //-- Return products whose name begins with "C", skipping
            //-- the first 4 products that begin with "C".  
            //-- Return single value (product name)
            using (var ctx = new EF360Context())
            {
                var querySingleValue = (from p in ctx.Products
                                        where p.ProductName.StartsWith("C")
                                        orderby p.ProductName
                                        select p.ProductName).Skip(4);
                gvSingeValue.DataSource = querySingleValue;
                gvSingeValue.DataBind();
            }

            //-- Project Multiple Elements - Anonymous Type
            //-- Next, demonstrate type inference by /projecting against anon type.
            //-- Compiler 'infers' type from right-hand side of expression
            //-- Hover over var to show inferred type
            using (var ctx = new EF360Context())
            {
                //-- Compiler infrers type                
                var query =
                    from p in ctx.Products.Include("Category")
                    group p by p.Category.CategoryID
                        into g
                        orderby g.Count() descending
                        //-- 'Select new {}' tells compiler to build anon type
                        //-- Anon type becomes our projection, or result set.
                        select new
                                   {
                                       //-- Demonstrate 'aggegrate query operators'
                                       TotalPrice = g.Sum(p => p.UnitPrice),
                                       LowPrice = g.Min(p => p.UnitPrice),
                                       HighPrice = g.Max(p => p.UnitPrice),
                                       AveragePrice = g.Average(p => p.UnitPrice)
                                   };

                gvInfer.DataSource = query;
                gvInfer.DataBind();
            }

            //-- Project Multiple Elements - Concrete Type
            //-- Explicilty specifiy concrete class 
            //-- IQueryable variable of type 'LongHandResultSet'
            using (var ctx = new EF360Context())
            {
                //-- Specify concrete class
                var query2 =
                    from p in ctx.Products.Include("Category")
                    group p by p.Category.CategoryID
                        into g
                        orderby g.Count() descending
                        //-- Instantiate concrete class
                        select new ConcreteClass
                                   {
                                       //-- Explicitly assign assign sequence values
                                       TotalPrice = g.Sum(p => p.UnitPrice),
                                       LowPrice = g.Min(p => p.UnitPrice),
                                       HighPrice = g.Max(p => p.UnitPrice),
                                       AveragePrice = g.Average(p => p.UnitPrice)
                                   };

                gvExplicit.DataSource = query2;
                gvExplicit.DataBind();
            }
        }
    }
}