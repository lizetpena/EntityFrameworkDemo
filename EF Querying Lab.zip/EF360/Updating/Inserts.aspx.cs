﻿using System;
using System.Data.Objects;
using System.Linq;
using System.Web.UI;
using DAL.Model;

namespace EF360CodeOnly.Updating
{
    public partial class Inserts : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (var ctx = new EF360Context())
                {
                    // Insert Data

                    // Add new "unattached" category entity
                    var category = new Category
                                       {
                                           CategoryName = "FoodType" + new Random().Next(100)
                                       };

                    // Add new "unattached" product entity
                    var product = new Product
                                      {
                                          ProductName = "NewProduct" + new Random().Next(100),
                                          QuantityPerUnit = "10",
                                          UnitPrice = 10,
                                      };

                    // Peak into ObjectStateManager
                    // Determine 'state' of new Category
                    var state = PeakIntoEntityState(category, ctx);
                    state = PeakIntoEntityState(product, ctx);

                    // Fun begins here
                    // Step #1: Attach new child (product) to new parent (category)
                    // Leveraging inferred relationship
                    category.Products.Add(product);

                    // Step #2: Attach new Category entity (parent entity) to Context
                    // Context becomes aware of Category entity 
                    // Entity state now becomes 'Added'
                    ctx.Categories.AddObject(category);

                    // Peak into ObjectStateManager
                    // What is 'state' of new Category?
                    state = PeakIntoEntityState(category, ctx);
                    state = PeakIntoEntityState(product, ctx);

                    // EF generates 'insert' statements
                    // Because of inferred relationship, EF will:
                    // 1) Insert parent (Category) and grabs new categoryId
                    // 2) Insert child (USAProduct) with new categoryId as FK.
                    // 3) Return Identity values for each and insert into entity objects.
                    ctx.SaveChanges();

                    // Retrieve new primary key values.
                    // EF has automatically inserted new primary keys into exsiting entities
                    var newCateoryId = category.CategoryID;
                    var newProductId = product.ProductID;

                    #region Requery database

                    var requeryDatabase =
                    from p in ctx.Products
                    where p.ProductID >= newProductId
                    select new
                    {
                        category.CategoryName,
                        category.CategoryID,
                        product.ProductName,
                        product.ProductID,
                        product.UnitPrice,
                        product.QuantityPerUnit
                    };

                    #endregion
                    
                    gvEF.DataSource = requeryDatabase;
                    gvEF.DataBind();
                }
            }
        }

        private static string PeakIntoEntityState<T>(T targetEntity, ObjectContext ctx)
        {
            //Peak into 'state' of current entity, as tracked by ObjectStateManager
            ObjectStateEntry entityState = null;
            return ctx.ObjectStateManager.TryGetObjectStateEntry(targetEntity, out entityState) ? entityState.State.ToString() : "Unattached"; 
        }
    }
}