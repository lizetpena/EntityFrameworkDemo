﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Transactions;
using DAL.Model;

namespace EF360CodeOnly.Updating
{
    public partial class Updates : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (var ctx = new EF360Context())
                {
                    #region Ignore for Demo -- Create 'Before Result Set'

                    var queryBefore =
                        from c in ctx.Customers.Include("Orders")
                        where c.CustomerID == "LONEP"
                        select new
                        {
                            c.Address,
                            c.City,
                            c.CompanyName,
                            c.ContactName,
                            c.PostalCode,
                            FreightCosts = c.Orders.FirstOrDefault().Freight
                        };

                    gvInsertBefore.DataSource = queryBefore.ToList();
                    gvInsertBefore.DataBind();
                    
                    #endregion

                    // Update Code
                    // Note the use of Include() to eager join Orders with Developer
                    var customer = ctx.Customers.Include("Orders").FirstOrDefault(c => c.CustomerID == "LONEP");

                    // Peak into 'state' of customer entity, as tracked by ObjectStateManager
                    var state = PeakIntoEntityState(customer, ctx);

                    // Peak into 'initial values' of current entity, as cached by ObjectContext
                    var address = PeakInitialValues(customer, "Address", ctx);
                    var city = PeakInitialValues(customer, "City", ctx);
                    var zip = PeakInitialValues(customer, "PostalCode", ctx);

                    // Modify postal code
                    customer.PostalCode = (int.Parse(customer.PostalCode) + 1).ToString();

                    // Modify freight charge
                    var freight = Convert.ToInt32(customer.Orders.FirstOrDefault().Freight); // Get first freight charge
                    customer.Orders.FirstOrDefault().Freight = freight + 1;

                    // Modifications will have changed 'State' of entity
                    state = PeakIntoEntityState(customer, ctx);

                    // Peak into 'current values' of current entity, as cached by ObjectContext
                    address = PeakChangedValues(customer, "Address", ctx);
                    city = PeakChangedValues(customer, "City", ctx);
                    zip = PeakChangedValues(customer, "PostalCode", ctx);

                    // Perform Update
                    // Call SumbitChanges() to commit our change.
                    // Based upon state of the current entity, entity framework will
                    // build appropriate Update and update both Developer and Order tables
                    ctx.SaveChanges();

                    // Check entity state again
                    state = PeakIntoEntityState(customer, ctx);

                    // Call SaveChanges again -- this time no update
                    ctx.SaveChanges();

                    #region Ignore -- Create 'After Result Set'

                    var queryAfter =
                        from c in ctx.Customers
                        where c.CustomerID == "LONEP"
                        select new
                        {
                            c.Address,
                            c.City,
                            c.CompanyName,
                            c.ContactName,
                            c.PostalCode,
                            FreightCosts = c.Orders.FirstOrDefault().Freight
                        };

                    #endregion

                    gvInsertAfter.DataSource = queryAfter.ToList();
                    gvInsertAfter.DataBind();
                }
            }
        }
        
        private static string PeakIntoEntityState<T>(T targetEntity, ObjectContext ctx)
        {
            ////Peak into 'state' of current entity, as tracked by ObjectStateManager, 
            ////which we reference from the underlying ObjectContext object
            ObjectStateEntry entityState = null;
            return ctx.ObjectStateManager.TryGetObjectStateEntry(targetEntity, out entityState) ? entityState.State.ToString() : string.Empty;
        }

        private static string PeakInitialValues<T>(T targetEntity, string field, ObjectContext ctx)
        {
            return ctx.ObjectStateManager.GetObjectStateEntry(targetEntity).OriginalValues[field].ToString();
        }

        private static string PeakChangedValues<T>(T targetEntity, string field, ObjectContext ctx)
        {
            return ctx.ObjectStateManager.GetObjectStateEntry(targetEntity).CurrentValues[field].ToString();
        }
    }
}